<!-- /.content-wrapper -->
<footer class="main-footer">
    <div class="pull-right hidden-xs">Version 1.0</div>
    Copyright &copy; 2015 - 2022 Xtreamer. All rights reserved by <a target="_blank" href="https://themeforest.net/user/uxliner">UXLiner</a> </footer>
</div>
<!-- ./wrapper --> 

<!-- jQuery --> 
<script src="dist/js/jquery.min.js"></script> 
<script src="dist/bootstrap/js/popper.min.js"></script> 
<script src="dist/bootstrap/js/bootstrap.min.js"></script> 
<script src="dist/js/tempapp.js"></script> 
<script src="dist/plugins/jquery-sparklines/jquery.sparkline.min.js"></script> 
<script src="dist/plugins/jquery-sparklines/sparkline-int.js"></script> 
<script src="dist/plugins/raphael/raphael-min.js"></script> 
<script src="dist/plugins/morris/morris.js"></script> 
<script src="dist/plugins/functions/morris-init.js"></script>
</body>

<!-- Mirrored from uxliner.net/xtreamer/demo/main/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 27 Jun 2023 17:07:31 GMT -->
</html>
